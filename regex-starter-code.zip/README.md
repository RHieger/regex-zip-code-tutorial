# Tutorial on Regular Expressions—Zip Code Example

This repository contains all development for a tutorial that will be
published on Medium.com under JavaScript in Plain English.

Targeted publication date is 05/08/2022.

For further information, visit the [wiki](https://github.com/RHieger/regex-zip-code-tutorial/wiki).
