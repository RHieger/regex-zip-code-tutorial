/**
 * 
 * Regex Zip Code Tutorial--Mini Web Application
 * 
 * Robert Hieger
 * 
 * Validates and dynamically updates display to show
 * matches of valid zip codes from test string.
 * 
 * The software contained in this tutorial is licensed
 * under the GNU GENERAL PUBLIC LICENSE version 3,
 * June 29, 2007 included in this archive.
 * 
 */

// Capture necessary DOM nodes.

/* TO BE DONE: DOM Node Objects */

// Test String to be passed to regular expression: 

/* TO BE DONE: Declare test string. */

// Regular Expression to which testString will be passed:

/* TO BE DONE: Declare regular expression. */

// Store pattern matches to matches variable:

/* TO BE DONE: declare variable that contains result
 * of testString passed to regular expression.
*/

// Functions to manage match data returned by regex engine:

/** These functions derive loosely from a YouTube
 *  tutorial at this URL:
 *  https://www.youtube.com/watch?v=1s4s_lU83pM
 * 
*/

// Function to Create Paragraph Element:

/* TO BE DONE: createParagraph() */


// Function to Add Paragraph (match) to Result Box:

/* TO BE DONE: appendParagraphs() */

// Function to set textContent for all match paragraphs:

/* TO BE DONE: paragraphText[] */

// Function to Populate Result Box with finished paragraphs:

/* TO BE DONE: populateResultBox() */

// Function to Remove result Paragraphs from Result Box:

/* TO BE DONE: depopulateResultBox() */

// Event Listeners to populate Result Box and depopulate it:

/* TO BE DONE: Event Listener for Validate Zip Codes Button */

/* TO BE DONE: Event Listener for Reset Button */
